# QR Send – gửi file qua mã QR

App Android: chọn file → hiện mã QR → máy khác (cùng Wi-Fi) quét là tải về.

## Build APK bằng GitHub Actions
1. Giải nén zip, đẩy toàn bộ thư mục lên repo GitHub (nhánh `main`).
2. Vào tab **Actions** → workflow **Build APK** (tự chạy khi push, hoặc bấm *Run workflow*).
3. Chạy xong, tải file `QRSend-APK` ở mục **Artifacts**, giải nén ra file `.apk` và cài.

APK ký bằng keystore cố định `app/qrsend.keystore` nên các bản sau cài đè được lên bản trước.

## Tính năng
- **Gửi file:** chọn file -> hiện QR -> máy khác quét và tải (có tải tiếp khi mạng chập chờn).
- **Nhận file:** máy khác quét QR, chọn file rồi gửi sang điện thoại. Chọn nơi lưu ở tab "Nhận file"
  (mặc định: Download/QRSend).
- **Ủng hộ:** QR ngân hàng của tác giả nằm ở `app/src/main/res/drawable-nodpi/donate_qr.png`
  (thay file này nếu muốn đổi QR).
