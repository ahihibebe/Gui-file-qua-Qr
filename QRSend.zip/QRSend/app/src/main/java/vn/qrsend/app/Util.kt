package vn.qrsend.app

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale

object Fmt {
    fun size(b: Long): String {
        if (b < 0) return "?"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = 0
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return if (i == 0) "$b B" else String.format(Locale.US, "%.1f %s", v, units[i])
    }
}

object NetUtil {
    /** Tìm IPv4 cục bộ của Wi-Fi / điểm phát sóng / LAN. Trả về null nếu không có. */
    fun findLocalIp(): String? {
        var best: String? = null
        var bestScore = 100
        val ifaces = try {
            NetworkInterface.getNetworkInterfaces()
        } catch (e: Exception) {
            null
        } ?: return null
        for (ni in ifaces) {
            try {
                if (!ni.isUp || ni.isLoopback) continue
            } catch (e: Exception) {
                continue
            }
            val name = ni.name.lowercase()
            val score = when {
                name.startsWith("wlan") || name.startsWith("ap") ||
                    name.startsWith("swlan") || name.startsWith("softap") -> 0
                name.startsWith("eth") -> 1
                name.startsWith("rmnet") || name.startsWith("ccmni") ||
                    name.startsWith("tun") || name.startsWith("dummy") -> 9
                else -> 5
            }
            if (score >= 9) continue
            for (addr in ni.inetAddresses) {
                if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                    if (score < bestScore) {
                        bestScore = score
                        best = addr.hostAddress
                    }
                }
            }
        }
        return best
    }
}

object QrUtil {
    fun make(text: String, size: Int): Bitmap {
        val hints = mapOf(
            EncodeHintType.MARGIN to 1,
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val w = m.width
        val h = m.height
        val px = IntArray(w * h)
        for (y in 0 until h) {
            val o = y * w
            for (x in 0 until w) {
                px[o + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}

/** Tạo chuỗi VietQR (chuẩn NAPAS 247 / EMVCo) hoàn toàn offline. */
object VietQr {
    private fun tlv(id: String, v: String) = id + v.length.toString().padStart(2, '0') + v

    fun build(bankBin: String, account: String, amount: Long?, note: String?): String {
        val hasAmount = amount != null && amount > 0
        val bank = tlv("00", bankBin) + tlv("01", account)
        val merchant = tlv("00", "A000000727") + tlv("01", bank) + tlv("02", "QRIBFTTA")
        val sb = StringBuilder()
        sb.append(tlv("00", "01"))
        sb.append(tlv("01", if (hasAmount) "12" else "11"))
        sb.append(tlv("38", merchant))
        sb.append(tlv("53", "704"))
        if (hasAmount) sb.append(tlv("54", amount.toString()))
        sb.append(tlv("58", "VN"))
        if (!note.isNullOrEmpty()) sb.append(tlv("62", tlv("08", note)))
        sb.append("6304")
        sb.append(crc16(sb.toString()))
        return sb.toString()
    }

    private fun crc16(s: String): String {
        var crc = 0xFFFF
        for (b in s.toByteArray(Charsets.US_ASCII)) {
            crc = crc xor ((b.toInt() and 0xFF) shl 8)
            for (i in 0 until 8) {
                crc = if ((crc and 0x8000) != 0) (crc shl 1) xor 0x1021 else (crc shl 1)
                crc = crc and 0xFFFF
            }
        }
        return String.format(Locale.US, "%04X", crc)
    }
}
