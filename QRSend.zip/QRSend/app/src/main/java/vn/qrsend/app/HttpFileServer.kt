package vn.qrsend.app

import android.content.Context
import android.os.ParcelFileDescriptor
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Máy chủ HTTP tối giản chạy trên điện thoại.
 *  - Truyền file theo từng mảnh [CHUNK] byte, không nạp cả file vào RAM.
 *  - Hỗ trợ header Range / If-Range để tải tiếp khi đứt kết nối.
 */
class HttpFileServer(private val context: Context) {

    companion object {
        const val CHUNK = 256 * 1024
    }

    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    private val openSockets: MutableSet<Socket> =
        Collections.newSetFromMap(ConcurrentHashMap<Socket, Boolean>())
    @Volatile private var stopped = false
    var port = 0
        private set

    fun start(): Int {
        var s: ServerSocket? = null
        for (p in 8080..8099) {
            try {
                s = ServerSocket(p)
                break
            } catch (_: IOException) {
            }
        }
        val server = s ?: ServerSocket(0)
        serverSocket = server
        port = server.localPort
        stopped = false
        Thread({ acceptLoop(server) }, "qrsend-accept").start()
        return port
    }

    fun stop() {
        stopped = true
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        for (s in openSockets.toList()) {
            try {
                s.close()
            } catch (_: Exception) {
            }
        }
        pool.shutdownNow()
    }

    private fun acceptLoop(server: ServerSocket) {
        while (!stopped && !server.isClosed) {
            try {
                val c = server.accept()
                pool.execute { handle(c) }
            } catch (e: Exception) {
                if (stopped || server.isClosed) break
                try {
                    Thread.sleep(50)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            if (sb.length > 8192) return null
        }
        return sb.toString()
    }

    private fun handle(sock: Socket) {
        openSockets.add(sock)
        try {
            sock.soTimeout = 20000
            sock.tcpNoDelay = true
            try {
                sock.sendBufferSize = 512 * 1024
            } catch (_: Exception) {
            }
            val input = BufferedInputStream(sock.getInputStream(), 4096)
            val out = sock.getOutputStream()
            val reqLine = readLine(input) ?: return
            val parts = reqLine.split(' ')
            if (parts.size < 2) {
                respondText(out, 400, "Bad Request", "Bad request")
                return
            }
            val method = parts[0].uppercase()
            val rawPath = parts[1]
            val headers = HashMap<String, String>()
            var count = 0
            while (count++ < 64) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }
            if (method != "GET" && method != "HEAD" && method != "PUT") {
                respondText(out, 405, "Method Not Allowed", "Method not allowed")
                return
            }
            route(out, input, method, rawPath, headers)
        } catch (_: Exception) {
            // Máy nhận ngắt kết nối giữa chừng - bình thường.
        } finally {
            openSockets.remove(sock)
            try {
                sock.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun route(out: OutputStream, input: InputStream, method: String, rawPath: String, h: Map<String, String>) {
        val path = rawPath.substringBefore('?').substringBefore('#')
        val segs = path.split('/').filter { it.isNotEmpty() }
        if (segs.isEmpty() || segs[0] != ShareState.token) {
            respondText(
                out, 404, "Not Found",
                "Hãy quét mã QR trên điện thoại gửi để mở đúng liên kết.", method
            )
            return
        }
        if (method == "PUT") {
            if (ShareState.receiveMode && segs.size >= 3 && segs[1] == "up") {
                val name = try {
                    java.net.URLDecoder.decode(segs[2], "UTF-8")
                } catch (e: Exception) {
                    segs[2]
                }
                receiveFile(out, input, name, h)
            } else {
                respondText(out, 405, "Method Not Allowed", "Không nhận file ở chế độ này.")
            }
            return
        }
        if (!ShareState.receiveMode && segs.size >= 3 && segs[1] == "f") {
            val id = segs[2].toIntOrNull()
            val f = if (id != null) ShareState.find(id) else null
            if (f == null) {
                respondText(out, 404, "Not Found", "Không tìm thấy file.", method)
                return
            }
            serveFile(out, method, f, h)
            return
        }
        if (ShareState.receiveMode) serveUploadPage(out, method) else serveIndex(out, method)
    }

    private fun cleanName(raw: String): String {
        var n = raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim()
        if (n.length > 150) n = n.take(150)
        if (n.isEmpty() || n == "." || n == "..") n = "file"
        return n
    }

    private fun receiveFile(out: OutputStream, input: InputStream, rawName: String, h: Map<String, String>) {
        val len = h["content-length"]?.toLongOrNull()
        if (len == null || len < 0) {
            respondText(out, 411, "Length Required", "Thiếu Content-Length")
            return
        }
        val name = cleanName(rawName)
        val item = ReceivedFile(name, len)
        ShareState.received.add(item)
        val target = try {
            ReceiveStore.create(context, name)
        } catch (e: Exception) {
            item.state = 2
            respondText(out, 500, "Internal Server Error", "Không ghi được file: " + e.message)
            return
        }
        ShareState.activeConnections.incrementAndGet()
        try {
            val buf = ByteArray(CHUNK)
            var remaining = len
            while (remaining > 0) {
                val want = if (remaining < buf.size) remaining.toInt() else buf.size
                val n = input.read(buf, 0, want)
                if (n < 0) throw IOException("Máy gửi ngắt kết nối")
                target.out.write(buf, 0, n)
                remaining -= n
                item.received.addAndGet(n.toLong())
                ShareState.totalReceived.addAndGet(n.toLong())
            }
            target.finish()
            item.savedAs = target.displayName
            item.state = 1
            respondText(out, 200, "OK", "OK")
        } catch (e: Exception) {
            item.state = 2
            target.abort()
            throw e
        } finally {
            ShareState.activeConnections.decrementAndGet()
        }
    }

    private fun serveUploadPage(out: OutputStream, method: String) {
        val token = ShareState.token
        val html = "<!doctype html><html lang=\"vi\"><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>QR Send</title><style>" +
            ":root{--bg:#f2f2f7;--card:#fff;--tx:#1c1c1e;--sub:#8e8e93;--ac:#007aff}" +
            "@media(prefers-color-scheme:dark){:root{--bg:#000;--card:#1c1c1e;--tx:#fff}}" +
            "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font-family:-apple-system,system-ui,Roboto,sans-serif}" +
            ".w{max-width:640px;margin:0 auto;padding:24px 16px}h1{font-size:28px;margin:0 0 4px}p.s{color:var(--sub);margin:0 0 20px}" +
            ".drop{border:2px dashed var(--ac);border-radius:20px;padding:36px 16px;text-align:center;color:var(--ac);font-weight:700;font-size:18px;background:var(--card);cursor:pointer}" +
            ".drop.o{background:rgba(0,122,255,.12)}.it{background:var(--card);border-radius:16px;padding:12px 14px;margin-top:10px}" +
            ".it b{display:block;word-break:break-word}.it span{color:var(--sub);font-size:13px}" +
            ".bar{height:6px;background:rgba(142,142,147,.3);border-radius:3px;margin-top:8px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:var(--ac)}" +
            "input{display:none}</style></head><body><div class=\"w\"><h1>📥 Gửi file sang điện thoại</h1>" +
            "<p class=\"s\">Chọn file (hoặc kéo thả vào khung), file sẽ được lưu thẳng vào điện thoại.</p>" +
            "<label class=\"drop\" id=\"d\">Chọn file để gửi<input type=\"file\" id=\"f\" multiple></label><div id=\"l\"></div></div>" +
            "<script>var T='" + token + "',q=[],busy=false,L=document.getElementById('l');" +
            "function sz(b){var u=['B','KB','MB','GB'],i=0;while(b>=1024&&i<3){b/=1024;i++}return (i?b.toFixed(1):b)+' '+u[i]}" +
            "function add(fs){for(var i=0;i<fs.length;i++){var f=fs[i],e=document.createElement('div');e.className='it';" +
            "e.innerHTML='<b></b><span>Đang chờ • '+sz(f.size)+'</span><div class=\"bar\"><i></i></div>';e.firstChild.textContent=f.name;L.appendChild(e);q.push({f:f,e:e})}run()}" +
            "function run(){if(busy||!q.length)return;busy=true;var j=q.shift(),x=new XMLHttpRequest(),s=j.e.querySelector('span'),b=j.e.querySelector('i');" +
            "x.open('PUT','/'+T+'/up/'+encodeURIComponent(j.f.name));" +
            "x.upload.onprogress=function(ev){if(ev.lengthComputable){b.style.width=(ev.loaded*100/ev.total)+'%';s.textContent='Đang gửi '+Math.round(ev.loaded*100/ev.total)+'% • '+sz(j.f.size)}};" +
            "x.onload=function(){busy=false;if(x.status==200){b.style.width='100%';s.textContent='✓ Đã gửi xong • '+sz(j.f.size)}else{s.textContent='✗ Lỗi ('+x.status+')'}run()};" +
            "x.onerror=function(){busy=false;s.textContent='✗ Mất kết nối';run()};x.send(j.f)}" +
            "document.getElementById('f').onchange=function(){add(this.files);this.value=''};" +
            "var d=document.getElementById('d');d.ondragover=function(e){e.preventDefault();d.className='drop o'};d.ondragleave=function(){d.className='drop'};" +
            "d.ondrop=function(e){e.preventDefault();d.className='drop';add(e.dataTransfer.files)};</script></body></html>"
        respondText(out, 200, "OK", html, method, "text/html; charset=utf-8")
    }

    private fun respondText(
        out: OutputStream, code: Int, msg: String, body: String,
        method: String = "GET", contentType: String = "text/plain; charset=utf-8"
    ) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val head = StringBuilder()
        head.append("HTTP/1.1 ").append(code).append(' ').append(msg).append("\r\n")
        head.append("Content-Type: ").append(contentType).append("\r\n")
        head.append("Content-Length: ").append(bytes.size).append("\r\n")
        head.append("Cache-Control: no-store\r\n")
        head.append("Connection: close\r\n\r\n")
        out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
        if (method != "HEAD") out.write(bytes)
        out.flush()
    }

    private fun respond416(out: OutputStream, total: Long) {
        val head = "HTTP/1.1 416 Range Not Satisfiable\r\n" +
            "Content-Range: bytes */" + total + "\r\n" +
            "Content-Length: 0\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun serveFile(out: OutputStream, method: String, f: SharedFile, h: Map<String, String>) {
        val pfd: ParcelFileDescriptor? = try {
            context.contentResolver.openFileDescriptor(f.uri, "r")
        } catch (e: Exception) {
            null
        }
        if (pfd == null) {
            respondText(out, 404, "Not Found", "Không mở được file (có thể đã bị xoá hoặc di chuyển).", method)
            return
        }
        try {
            val stat = pfd.statSize
            val total = if (stat >= 0) stat else f.size
            val etag = "\"" + f.id + "-" + total + "\""

            var start = 0L
            var end = if (total >= 0) total - 1 else -1L
            var partial = false

            val rangeHdr = h["range"]
            val ifRange = h["if-range"]
            val useRange = total >= 0 && rangeHdr != null &&
                rangeHdr.startsWith("bytes=") && (ifRange == null || ifRange == etag)
            if (useRange) {
                val spec = rangeHdr!!.substring(6).trim()
                if (!spec.contains(',')) {
                    val dash = spec.indexOf('-')
                    if (dash >= 0) {
                        val a = spec.substring(0, dash).trim()
                        val b = spec.substring(dash + 1).trim()
                        var s = -1L
                        var e = -1L
                        try {
                            if (a.isEmpty()) {
                                val n = b.toLong()
                                s = maxOf(0L, total - n)
                                e = total - 1
                            } else {
                                s = a.toLong()
                                e = if (b.isEmpty()) total - 1 else minOf(b.toLong(), total - 1)
                            }
                        } catch (_: NumberFormatException) {
                            s = -1L
                        }
                        if (s < 0 || e < s || s >= total) {
                            respond416(out, total)
                            return
                        }
                        start = s
                        end = e
                        partial = true
                    }
                }
            }

            val length = if (total >= 0) end - start + 1 else -1L
            val chunked = length < 0

            val sb = StringBuilder()
            sb.append(if (partial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n")
            sb.append("Content-Type: ").append(f.mime).append("\r\n")
            if (total >= 0) sb.append("Accept-Ranges: bytes\r\n")
            sb.append("ETag: ").append(etag).append("\r\n")
            sb.append("Content-Disposition: attachment; filename=\"").append(asciiName(f.name))
                .append("\"; filename*=UTF-8''").append(urlEnc(f.name)).append("\r\n")
            if (chunked) {
                sb.append("Transfer-Encoding: chunked\r\n")
            } else {
                sb.append("Content-Length: ").append(length).append("\r\n")
                if (partial) sb.append("Content-Range: bytes ").append(start).append('-').append(end)
                    .append('/').append(total).append("\r\n")
            }
            sb.append("Cache-Control: no-cache\r\nConnection: close\r\n\r\n")
            out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
            if (method == "HEAD") {
                out.flush()
                return
            }

            val fis = FileInputStream(pfd.fileDescriptor)
            if (start > 0) {
                try {
                    fis.channel.position(start)
                } catch (e: IOException) {
                    var toSkip = start
                    while (toSkip > 0) {
                        val n = fis.skip(toSkip)
                        if (n <= 0) break
                        toSkip -= n
                    }
                }
            }

            f.active.incrementAndGet()
            ShareState.activeConnections.incrementAndGet()
            try {
                f.progress.set(start)
                val buf = ByteArray(CHUNK)
                var remaining = if (chunked) Long.MAX_VALUE else length
                while (remaining > 0) {
                    val want = if (remaining < buf.size) remaining.toInt() else buf.size
                    val n = fis.read(buf, 0, want)
                    if (n < 0) break
                    if (n == 0) continue
                    if (chunked) {
                        out.write((Integer.toHexString(n) + "\r\n").toByteArray(Charsets.ISO_8859_1))
                        out.write(buf, 0, n)
                        out.write("\r\n".toByteArray(Charsets.ISO_8859_1))
                    } else {
                        out.write(buf, 0, n)
                    }
                    remaining -= n
                    ShareState.totalSent.addAndGet(n.toLong())
                    f.progress.addAndGet(n.toLong())
                }
                if (chunked) out.write("0\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
                out.flush()
                if (chunked || remaining == 0L) f.completed.incrementAndGet()
            } finally {
                f.active.decrementAndGet()
                ShareState.activeConnections.decrementAndGet()
            }
        } finally {
            try {
                pfd.close()
            } catch (_: IOException) {
            }
        }
    }

    private fun serveIndex(out: OutputStream, method: String) {
        val token = ShareState.token
        val sb = StringBuilder()
        sb.append(
            "<!doctype html><html lang=\"vi\"><head><meta charset=\"utf-8\">" +
                "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
                "<title>QR Send</title><style>" +
                ":root{--bg:#f2f2f7;--card:#fff;--tx:#1c1c1e;--sub:#8e8e93;--ac:#007aff}" +
                "@media(prefers-color-scheme:dark){:root{--bg:#000;--card:#1c1c1e;--tx:#fff;--sub:#8e8e93}}" +
                "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);" +
                "font-family:-apple-system,system-ui,Roboto,sans-serif}" +
                ".w{max-width:640px;margin:0 auto;padding:24px 16px}" +
                "h1{font-size:28px;margin:0 0 4px}p.s{color:var(--sub);margin:0 0 20px}" +
                ".f{display:flex;align-items:center;gap:12px;background:var(--card);border-radius:16px;" +
                "padding:14px;margin-bottom:10px;text-decoration:none;color:var(--tx)}" +
                ".i{font-size:28px}.n{flex:1;min-width:0}.n b{display:block;word-break:break-word}" +
                ".n span{color:var(--sub);font-size:13px}" +
                ".b{background:var(--ac);color:#fff;border-radius:999px;padding:8px 16px;font-weight:600;font-size:14px}" +
                "footer{color:var(--sub);font-size:12px;text-align:center;margin-top:20px}" +
                "</style></head><body><div class=\"w\"><h1>📤 File được chia sẻ</h1>" +
                "<p class=\"s\">Bấm vào file để tải về. Nếu mạng chập chờn, tải lại sẽ tiếp tục từ chỗ dừng.</p>"
        )
        for (f in ShareState.files) {
            val href = "/" + token + "/f/" + f.id + "/" + urlEnc(f.name)
            sb.append("<a class=\"f\" href=\"").append(href).append("\" download>")
                .append("<div class=\"i\">").append(iconFor(f.name)).append("</div>")
                .append("<div class=\"n\"><b>").append(esc(f.name)).append("</b><span>")
                .append(Fmt.size(f.size)).append("</span></div>")
                .append("<div class=\"b\">Tải về</div></a>")
        }
        sb.append("<footer>Gửi bằng QR Send</footer></div></body></html>")
        respondText(out, 200, "OK", sb.toString(), method, "text/html; charset=utf-8")
    }

    private fun iconFor(name: String): String {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "apk" -> "📦"
            "zip", "rar", "7z", "tar", "gz" -> "🗜️"
            "mp4", "mkv", "avi", "mov", "webm" -> "🎬"
            "mp3", "wav", "flac", "m4a", "ogg" -> "🎵"
            "jpg", "jpeg", "png", "gif", "webp", "heic" -> "🖼️"
            "pdf" -> "📕"
            "doc", "docx" -> "📝"
            "xls", "xlsx", "csv" -> "📊"
            "ppt", "pptx" -> "📽️"
            else -> "📄"
        }
    }

    private fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

    private fun asciiName(n: String): String {
        val sb = StringBuilder()
        for (c in n) sb.append(if (c.code in 32..126 && c != '"' && c != '\\') c else '_')
        return sb.toString()
    }

    private fun urlEnc(n: String): String =
        URLEncoder.encode(n, "UTF-8").replace("+", "%20").replace("*", "%2A")
}
