package vn.qrsend.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQ_PICK = 11
        private const val REQ_NOTIF = 12
        private const val REQ_TREE = 13

        // ===== THÔNG TIN DONATE (MB Bank) =====
        private const val BANK_NAME = "MB Bank (Ngân hàng Quân Đội)"
        private const val ACCOUNT = "220011026789"
        private const val DONATE_NOTE = "Goi Bim Bim"

        private val ACCENT = 0xFF007AFF.toInt()
        private val GREEN = 0xFF34C759.toInt()
        private val RED = 0xFFFF3B30.toInt()
        private val BG = 0xFFF2F2F7.toInt()
        private val TEXT = 0xFF1C1C1E.toInt()
        private val SUB = 0xFF8E8E93.toInt()
        private val LINE = 0xFFE5E5EA.toInt()
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private class RowRefs(val status: TextView, val bar: ProgressBar)

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var content: FrameLayout
    private lateinit var sendPage: ScrollView
    private lateinit var donatePage: ScrollView
    private val tabIcons = ArrayList<TextView>()
    private val tabLabels = ArrayList<TextView>()

    // Tab gửi file
    private lateinit var idleBox: LinearLayout
    private lateinit var fileHeader: TextView
    private lateinit var fileListBox: LinearLayout
    private lateinit var startBtn: TextView
    private lateinit var sharingBox: LinearLayout
    private lateinit var qrImage: ImageView
    private lateinit var urlText: TextView
    private lateinit var statsText: TextView
    private lateinit var progressBox: LinearLayout
    private val rows = HashMap<Int, RowRefs>()
    private var shownUrl: String? = null
    private var lastT = 0L
    private var lastSent = 0L
    private var speed = 0.0

    // Tab nhận file
    private lateinit var recvPage: ScrollView
    private lateinit var saveText: TextView
    private lateinit var recvIdleBox: LinearLayout
    private lateinit var recvRunBox: LinearLayout
    private lateinit var recvQr: ImageView
    private lateinit var recvUrl: TextView
    private lateinit var recvStats: TextView
    private lateinit var recvListBox: LinearLayout
    private lateinit var recvStartBtn: TextView
    private var shownRecvUrl: String? = null
    private var recvRows = 0
    private var rLastT = 0L
    private var rLastBytes = 0L
    private var rSpeed = 0.0

    // Tab ủng hộ
    private lateinit var donateQr: ImageView

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 500)
        }
    }

    // ---------- Helpers giao diện ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun bg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0, dashed: Boolean = false): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) {
            if (dashed) d.setStroke(dp(strokeDp), strokeColor, dp(8).toFloat(), dp(5).toFloat())
            else d.setStroke(dp(strokeDp), strokeColor)
        }
        return d
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun LinearLayout.addV(v: View, top: Int = 0, w: Int = MATCH, h: Int = WRAP) {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = dp(top)
        addView(v, p)
    }

    private fun card(): LinearLayout {
        val c = vbox()
        c.background = bg(Color.WHITE, 18)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        return c
    }

    private fun button(text: String, color: Int, onClick: () -> Unit): TextView {
        val b = tv(text, 16f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        b.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg(color, 14), null)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Đã sao chép")
    }

    // ---------- Vòng đời ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        sendPage = buildSendPage()
        recvPage = buildRecvPage()
        donatePage = buildDonatePage()
        content.addView(sendPage, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(recvPage, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(donatePage, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(buildTabBar(), LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(root)
        selectTab(0)
        refreshFileList()
        updateSaveText()
        showDonateQr()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (sendPage.visibility != View.VISIBLE) selectTab(0) else super.onBackPressed()
    }

    // ---------- Thanh tab ----------

    private fun buildTabBar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Color.WHITE)
        bar.elevation = dp(8).toFloat()
        val items = arrayOf(Pair("📤", "Gửi file"), Pair("📥", "Nhận file"), Pair("🍿", "Ủng hộ"))
        for ((i, it) in items.withIndex()) {
            val item = vbox()
            item.gravity = Gravity.CENTER
            item.setPadding(0, dp(8), 0, dp(8))
            val icon = tv(it.first, 22f, TEXT)
            icon.gravity = Gravity.CENTER
            val label = tv(it.second, 11f, SUB, true)
            label.gravity = Gravity.CENTER
            item.addView(icon, LinearLayout.LayoutParams(MATCH, WRAP))
            item.addView(label, LinearLayout.LayoutParams(MATCH, WRAP))
            item.setOnClickListener { selectTab(i) }
            tabIcons.add(icon)
            tabLabels.add(label)
            bar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return bar
    }

    private fun selectTab(i: Int) {
        sendPage.visibility = if (i == 0) View.VISIBLE else View.GONE
        recvPage.visibility = if (i == 1) View.VISIBLE else View.GONE
        donatePage.visibility = if (i == 2) View.VISIBLE else View.GONE
        for (k in tabIcons.indices) {
            val sel = k == i
            tabIcons[k].alpha = if (sel) 1f else 0.4f
            tabLabels[k].setTextColor(if (sel) ACCENT else SUB)
        }
    }

    // ---------- Tab GỬI FILE ----------

    private fun buildSendPage(): ScrollView {
        val sv = ScrollView(this)
        val col = vbox()
        col.setPadding(dp(20), dp(20), dp(20), dp(28))
        sv.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        col.addV(tv("Gửi file qua QR", 30f, TEXT, true))
        col.addV(tv("Chọn file, rồi quét mã QR bằng máy khác cùng Wi-Fi là tải được ngay. Không cần internet, không giới hạn dung lượng.", 15f, SUB), 4)

        // ----- Trạng thái chờ: chọn file -----
        idleBox = vbox()

        val picker = vbox()
        picker.gravity = Gravity.CENTER
        picker.setPadding(dp(16), dp(28), dp(16), dp(28))
        picker.background = RippleDrawable(
            ColorStateList.valueOf(0x22007AFF),
            bg(0xFFFFFFFF.toInt(), 20, ACCENT, 2, true), null
        )
        val pIcon = tv("📁", 40f, TEXT)
        pIcon.gravity = Gravity.CENTER
        val pTitle = tv("Chọn file để gửi", 19f, ACCENT, true)
        pTitle.gravity = Gravity.CENTER
        val pSub = tv("Mọi loại file • chọn được nhiều file cùng lúc", 13f, SUB)
        pSub.gravity = Gravity.CENTER
        picker.addV(pIcon)
        picker.addV(pTitle, 6)
        picker.addV(pSub, 2)
        picker.setOnClickListener { openPicker() }
        idleBox.addV(picker, 20)

        fileHeader = tv("", 13f, SUB, true)
        idleBox.addV(fileHeader, 22)
        fileListBox = vbox()
        idleBox.addV(fileListBox, 8)

        startBtn = button("Bắt đầu chia sẻ", ACCENT) { startSharing() }
        idleBox.addV(startBtn, 16)
        col.addV(idleBox)

        // ----- Trạng thái đang chia sẻ -----
        sharingBox = vbox()
        sharingBox.visibility = View.GONE

        val qrCard = card()
        qrCard.gravity = Gravity.CENTER_HORIZONTAL
        val pill = tv("●  Đang chia sẻ", 13f, GREEN, true)
        pill.setPadding(dp(12), dp(5), dp(12), dp(5))
        pill.background = bg(0x2234C759, 20)
        qrCard.addV(pill, 0, WRAP)

        qrImage = ImageView(this)
        qrImage.setBackgroundColor(Color.WHITE)
        qrImage.setPadding(dp(8), dp(8), dp(8), dp(8))
        qrImage.scaleType = ImageView.ScaleType.FIT_CENTER
        qrCard.addV(qrImage, 14, dp(260), dp(260))

        urlText = tv("", 14f, ACCENT, true)
        urlText.gravity = Gravity.CENTER
        urlText.setTextIsSelectable(true)
        qrCard.addV(urlText, 12)

        statsText = tv("", 13f, SUB)
        statsText.gravity = Gravity.CENTER
        qrCard.addV(statsText, 6)

        val copyBtn = button("Sao chép liên kết", 0xFF8E8E93.toInt()) {
            ShareState.url?.let { copy("Liên kết", it) }
        }
        qrCard.addV(copyBtn, 14)
        sharingBox.addV(qrCard, 18)

        val filesCard = card()
        filesCard.addV(tv("FILE ĐANG CHIA SẺ", 12f, SUB, true))
        progressBox = vbox()
        filesCard.addV(progressBox, 6)
        sharingBox.addV(filesCard, 14)

        sharingBox.addV(button("Dừng chia sẻ", RED) { stopSharing() }, 14)
        sharingBox.addV(
            tv("Máy nhận cần cùng Wi-Fi với điện thoại này (hoặc kết nối vào điểm phát sóng của nó). Có thể tắt màn hình, app vẫn chạy ngầm.", 12f, SUB),
            12
        )
        col.addV(sharingBox)
        return sv
    }

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            toast("Không mở được trình chọn file")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TREE) {
            val t = data?.data
            if (resultCode == RESULT_OK && t != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        t, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                    ReceiveStore.setTree(this, t)
                } catch (e: Exception) {
                    toast("Không dùng được thư mục này, hãy chọn thư mục khác")
                }
                updateSaveText()
            }
            return
        }
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
        }
        val single = data.data
        if (single != null && !uris.contains(single)) uris.add(single)
        for (u in uris) {
            if (ShareState.files.any { it.uri == u }) continue
            val f = describe(u)
            if (f != null) ShareState.files.add(f)
        }
        refreshFileList()
    }

    private fun describe(u: Uri): SharedFile? {
        var name: String? = null
        var size = -1L
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {
        }
        if (size < 0) {
            try {
                contentResolver.openFileDescriptor(u, "r")?.use { size = it.statSize }
            } catch (_: Exception) {
            }
        }
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val clean = (name ?: u.lastPathSegment ?: "file")
            .replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), "_")
        val mime = contentResolver.getType(u) ?: "application/octet-stream"
        return SharedFile(ShareState.nextId(), u, clean, size, mime)
    }

    private fun iconFor(name: String): String {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "apk" -> "📦"
            "zip", "rar", "7z", "tar", "gz" -> "🗜️"
            "mp4", "mkv", "avi", "mov", "webm" -> "🎬"
            "mp3", "wav", "flac", "m4a", "ogg" -> "🎵"
            "jpg", "jpeg", "png", "gif", "webp", "heic" -> "🖼️"
            "pdf" -> "📕"
            "doc", "docx" -> "📝"
            "xls", "xlsx", "csv" -> "📊"
            "ppt", "pptx" -> "📽️"
            else -> "📄"
        }
    }

    private fun refreshFileList() {
        fileListBox.removeAllViews()
        val files = ShareState.files
        if (files.isEmpty()) {
            fileHeader.visibility = View.GONE
            startBtn.visibility = View.GONE
            return
        }
        fileHeader.visibility = View.VISIBLE
        startBtn.visibility = View.VISIBLE
        var total = 0L
        for (f in files) if (f.size > 0) total += f.size
        fileHeader.text = "FILE ĐÃ CHỌN (" + files.size + ") • " + Fmt.size(total)

        for (f in files) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = bg(Color.WHITE, 16)
            row.setPadding(dp(14), dp(12), dp(8), dp(12))

            val ic = tv(iconFor(f.name), 26f, TEXT)
            row.addView(ic, LinearLayout.LayoutParams(WRAP, WRAP))

            val info = vbox()
            val n = tv(f.name, 15f, TEXT, true)
            n.maxLines = 2
            n.ellipsize = TextUtils.TruncateAt.MIDDLE
            info.addView(n)
            info.addView(tv(Fmt.size(f.size), 12f, SUB))
            val ip = LinearLayout.LayoutParams(0, WRAP, 1f)
            ip.leftMargin = dp(12)
            row.addView(info, ip)

            val x = tv("✕", 18f, SUB, true)
            x.gravity = Gravity.CENTER
            x.setPadding(dp(14), dp(8), dp(14), dp(8))
            x.setOnClickListener {
                ShareState.files.remove(f)
                refreshFileList()
            }
            row.addView(x, LinearLayout.LayoutParams(WRAP, WRAP))

            fileListBox.addV(row, 8)
        }
    }

    private fun startSharing() {
        if (ShareState.files.isEmpty()) return
        if (ShareState.running) {
            toast("Đang ở chế độ nhận file, hãy dừng trước")
            return
        }
        ShareState.receiveMode = false
        if (NetUtil.findLocalIp() == null) {
            AlertDialog.Builder(this)
                .setTitle("Chưa có mạng Wi-Fi")
                .setMessage("Hãy kết nối Wi-Fi hoặc bật điểm phát sóng (hotspot) để máy khác tải được file từ điện thoại này.")
                .setPositiveButton("Đã hiểu", null)
                .show()
            return
        }
        startBtn.isEnabled = false
        startBtn.text = "Đang khởi động…"
        startForegroundService(Intent(this, ShareService::class.java).setAction(ShareService.ACTION_START))
    }

    private fun stopSharing() {
        startService(Intent(this, ShareService::class.java).setAction(ShareService.ACTION_STOP))
    }

    private fun tick() {
        val err = ShareState.error
        if (err != null) {
            toast(err)
            ShareState.error = null
            startBtn.isEnabled = true
            startBtn.text = "Bắt đầu chia sẻ"
            recvStartBtn.isEnabled = true
            recvStartBtn.text = "Bắt đầu nhận file"
        }
        val url = ShareState.url
        val up = ShareState.running && url != null
        if (up && !ShareState.receiveMode) {
            if (shownUrl != url) showSharing(url!!)
            updateStats()
        } else if (shownUrl != null) {
            hideSharing()
        }
        if (up && ShareState.receiveMode) {
            if (shownRecvUrl != url) showReceiving(url!!)
            updateRecvStats()
        } else if (shownRecvUrl != null) {
            hideReceiving()
        }
    }

    private fun showSharing(url: String) {
        shownUrl = url
        idleBox.visibility = View.GONE
        sharingBox.visibility = View.VISIBLE
        qrImage.setImageBitmap(QrUtil.make(url, 900))
        urlText.text = url
        lastT = 0L
        lastSent = 0L
        speed = 0.0

        progressBox.removeAllViews()
        rows.clear()
        for (f in ShareState.files) {
            val r = vbox()
            val name = tv(iconFor(f.name) + "  " + f.name, 14f, TEXT, true)
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.MIDDLE
            r.addView(name)
            val status = tv("", 12f, SUB)
            r.addV(status, 2)
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            bar.isIndeterminate = false
            bar.max = 1000
            bar.progress = 0
            bar.progressTintList = ColorStateList.valueOf(ACCENT)
            bar.progressBackgroundTintList = ColorStateList.valueOf(LINE)
            r.addV(bar, 6, MATCH, dp(6))
            progressBox.addV(r, 14)
            rows[f.id] = RowRefs(status, bar)
        }
    }

    private fun hideSharing() {
        shownUrl = null
        sharingBox.visibility = View.GONE
        idleBox.visibility = View.VISIBLE
        startBtn.isEnabled = true
        startBtn.text = "Bắt đầu chia sẻ"
        refreshFileList()
    }

    private fun updateStats() {
        val now = SystemClock.elapsedRealtime()
        val sent = ShareState.totalSent.get()
        if (lastT > 0 && now > lastT) {
            val inst = (sent - lastSent) * 1000.0 / (now - lastT)
            speed = speed * 0.5 + inst * 0.5
        }
        lastT = now
        lastSent = sent
        val act = ShareState.activeConnections.get()
        statsText.text = if (act > 0) {
            "⬇ " + act + " lượt tải • " + Fmt.size(speed.toLong()) + "/s • đã gửi " + Fmt.size(sent)
        } else {
            "Sẵn sàng • đã gửi " + Fmt.size(sent)
        }
        for (f in ShareState.files) {
            val r = rows[f.id] ?: continue
            val size = f.size
            if (f.active.get() > 0) {
                val p = f.progress.get()
                val pct = if (size > 0) (p * 100 / size).toInt() else 0
                r.status.text = "Đang gửi… " + pct + "% (" + Fmt.size(p) + " / " + Fmt.size(size) + ")"
                r.bar.progress = if (size > 0) (p * 1000 / size).toInt() else 0
            } else if (f.completed.get() > 0) {
                r.status.text = "✓ Đã gửi " + f.completed.get() + " lần • " + Fmt.size(size)
                r.bar.progress = 1000
            } else {
                r.status.text = "Chờ máy nhận • " + Fmt.size(size)
                r.bar.progress = 0
            }
        }
    }

    // ---------- Tab NHẬN FILE ----------

    private fun buildRecvPage(): ScrollView {
        val sv = ScrollView(this)
        val col = vbox()
        col.setPadding(dp(20), dp(20), dp(20), dp(28))
        sv.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        col.addV(tv("Nhận file về máy", 30f, TEXT, true))
        col.addV(tv("Máy khác quét QR, chọn file rồi gửi sang điện thoại này. File được lưu vào thư mục bạn chọn.", 15f, SUB), 4)

        val saveCard = card()
        saveCard.addV(tv("NƠI LƯU FILE", 12f, SUB, true))
        saveText = tv("", 16f, TEXT, true)
        saveCard.addV(saveText, 6)
        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        val pick = button("Chọn thư mục", ACCENT) { pickSaveFolder() }
        val reset = button("Mặc định", 0xFF8E8E93.toInt()) {
            ReceiveStore.setTree(this, null)
            updateSaveText()
        }
        btnRow.addView(pick, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rp = LinearLayout.LayoutParams(0, WRAP, 1f)
        rp.leftMargin = dp(8)
        btnRow.addView(reset, rp)
        saveCard.addV(btnRow, 14)
        saveCard.addV(
            tv("Android 11+ không cho chọn thẳng thư mục Download gốc. Hãy chọn/tạo thư mục con, hoặc dùng mặc định.", 12f, SUB),
            10
        )
        col.addV(saveCard, 18)

        recvIdleBox = vbox()
        recvStartBtn = button("Bắt đầu nhận file", GREEN) { startReceiving() }
        recvIdleBox.addV(recvStartBtn, 0)
        col.addV(recvIdleBox, 16)

        recvRunBox = vbox()
        recvRunBox.visibility = View.GONE
        val qrCard = card()
        qrCard.gravity = Gravity.CENTER_HORIZONTAL
        val pill = tv("●  Đang chờ nhận file", 13f, GREEN, true)
        pill.setPadding(dp(12), dp(5), dp(12), dp(5))
        pill.background = bg(0x2234C759, 20)
        qrCard.addV(pill, 0, WRAP)
        recvQr = ImageView(this)
        recvQr.setBackgroundColor(Color.WHITE)
        recvQr.setPadding(dp(8), dp(8), dp(8), dp(8))
        recvQr.scaleType = ImageView.ScaleType.FIT_CENTER
        qrCard.addV(recvQr, 14, dp(260), dp(260))
        recvUrl = tv("", 14f, ACCENT, true)
        recvUrl.gravity = Gravity.CENTER
        recvUrl.setTextIsSelectable(true)
        qrCard.addV(recvUrl, 12)
        recvStats = tv("", 13f, SUB)
        recvStats.gravity = Gravity.CENTER
        qrCard.addV(recvStats, 6)
        qrCard.addV(button("Sao chép liên kết", 0xFF8E8E93.toInt()) {
            ShareState.url?.let { copy("Liên kết", it) }
        }, 14)
        recvRunBox.addV(qrCard, 0)

        val listCard = card()
        listCard.addV(tv("FILE ĐÃ NHẬN", 12f, SUB, true))
        recvListBox = vbox()
        listCard.addV(recvListBox, 6)
        recvRunBox.addV(listCard, 14)
        recvRunBox.addV(button("Dừng nhận file", RED) { stopSharing() }, 14)
        col.addV(recvRunBox, 0)
        return sv
    }

    private fun updateSaveText() {
        saveText.text = ReceiveStore.describe(this)
    }

    private fun pickSaveFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        try {
            startActivityForResult(i, REQ_TREE)
        } catch (e: Exception) {
            toast("Không mở được trình chọn thư mục")
        }
    }

    private fun startReceiving() {
        if (ShareState.running) {
            toast("Đang chia sẻ file, hãy dừng trước")
            return
        }
        if (NetUtil.findLocalIp() == null) {
            AlertDialog.Builder(this)
                .setTitle("Chưa có mạng Wi-Fi")
                .setMessage("Hãy kết nối Wi-Fi hoặc bật điểm phát sóng (hotspot) để máy khác gửi file sang được.")
                .setPositiveButton("Đã hiểu", null)
                .show()
            return
        }
        ShareState.receiveMode = true
        recvStartBtn.isEnabled = false
        recvStartBtn.text = "Đang khởi động…"
        startForegroundService(Intent(this, ShareService::class.java).setAction(ShareService.ACTION_START))
    }

    private fun showReceiving(url: String) {
        shownRecvUrl = url
        recvIdleBox.visibility = View.GONE
        recvRunBox.visibility = View.VISIBLE
        recvQr.setImageBitmap(QrUtil.make(url, 900))
        recvUrl.text = url
        recvRows = -1
        rLastT = 0L
        rLastBytes = 0L
        rSpeed = 0.0
    }

    private fun hideReceiving() {
        shownRecvUrl = null
        recvRunBox.visibility = View.GONE
        recvIdleBox.visibility = View.VISIBLE
        recvStartBtn.isEnabled = true
        recvStartBtn.text = "Bắt đầu nhận file"
    }

    private fun updateRecvStats() {
        val now = SystemClock.elapsedRealtime()
        val got = ShareState.totalReceived.get()
        if (rLastT > 0 && now > rLastT) {
            val inst = (got - rLastBytes) * 1000.0 / (now - rLastT)
            rSpeed = rSpeed * 0.5 + inst * 0.5
        }
        rLastT = now
        rLastBytes = got
        val act = ShareState.activeConnections.get()
        recvStats.text = if (act > 0) {
            "⬇ Đang nhận • " + Fmt.size(rSpeed.toLong()) + "/s • đã nhận " + Fmt.size(got)
        } else {
            "Sẵn sàng • đã nhận " + Fmt.size(got)
        }

        val list = ShareState.received
        if (recvRows != list.size) {
            recvRows = list.size
            recvListBox.removeAllViews()
            if (list.isEmpty()) {
                recvListBox.addV(tv("Chưa có file nào. Quét QR bằng máy khác để gửi.", 13f, SUB), 6)
            }
            for (f in list) {
                val r = vbox()
                val name = tv(iconFor(f.name) + "  " + f.name, 14f, TEXT, true)
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.MIDDLE
                r.addView(name)
                r.addV(tv("", 12f, SUB), 2)
                val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
                bar.isIndeterminate = false
                bar.max = 1000
                bar.progressTintList = ColorStateList.valueOf(ACCENT)
                bar.progressBackgroundTintList = ColorStateList.valueOf(LINE)
                r.addV(bar, 6, MATCH, dp(6))
                recvListBox.addV(r, 14)
            }
        }
        for (k in list.indices) {
            val f = list[k]
            val r = recvListBox.getChildAt(k) as? LinearLayout ?: continue
            val status = r.getChildAt(1) as TextView
            val bar = r.getChildAt(2) as ProgressBar
            val got2 = f.received.get()
            when (f.state) {
                1 -> {
                    status.text = "✓ Đã lưu: " + f.savedAs + " • " + Fmt.size(f.total)
                    status.setTextColor(GREEN)
                    bar.progress = 1000
                }
                2 -> {
                    status.text = "✗ Lỗi hoặc bị ngắt kết nối"
                    status.setTextColor(RED)
                }
                else -> {
                    val pct = if (f.total > 0) (got2 * 100 / f.total).toInt() else 0
                    status.text = "Đang nhận… " + pct + "% (" + Fmt.size(got2) + " / " + Fmt.size(f.total) + ")"
                    bar.progress = if (f.total > 0) (got2 * 1000 / f.total).toInt() else 0
                }
            }
        }
    }

    // ---------- Tab ỦNG HỘ ----------

    private fun buildDonatePage(): ScrollView {
        val sv = ScrollView(this)
        val col = vbox()
        col.setPadding(dp(20), dp(20), dp(20), dp(28))
        sv.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        col.addV(tv("Ủng hộ tác giả", 30f, TEXT, true))

        val hero = vbox()
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFFFF9500.toInt(), 0xFFFF2D55.toInt())
        )
        g.cornerRadius = dp(22).toFloat()
        hero.background = g
        hero.setPadding(dp(20), dp(20), dp(20), dp(20))
        hero.addV(tv("🍿 Gói Bim Bim", 26f, Color.WHITE, true))
        hero.addV(tv("Bà nào có lòng tui xin nhận và không thèm cảm ơn.", 16f, Color.WHITE), 6)
        col.addV(hero, 14)

        val qrCard = card()
        qrCard.gravity = Gravity.CENTER_HORIZONTAL
        donateQr = ImageView(this)
        donateQr.setBackgroundColor(Color.WHITE)
        donateQr.setPadding(dp(8), dp(8), dp(8), dp(8))
        donateQr.scaleType = ImageView.ScaleType.FIT_CENTER
        qrCard.addV(donateQr, 0, dp(260), dp(260))
        qrCard.addV(tv("Mở app ngân hàng bất kỳ → Quét QR", 12f, SUB).also { it.gravity = Gravity.CENTER }, 8)
        qrCard.addV(infoRow("Ngân hàng", BANK_NAME), 16)
        qrCard.addV(infoRow("Số tài khoản", ACCOUNT), 10)
        qrCard.addV(button("Sao chép số tài khoản", ACCENT) { copy("Số tài khoản", ACCOUNT) }, 16)
        col.addV(qrCard, 14)

        val about = card()
        about.addV(tv("Về QR Send", 17f, TEXT, true))
        about.addV(
            tv(
                "• Gửi và nhận file trực tiếp qua Wi-Fi, không qua internet\n" +
                    "• Truyền theo từng mảnh nhỏ nên file lớn cũng không tốn RAM\n" +
                    "• Tải tiếp được khi mạng chập chờn (HTTP Range)\n" +
                    "• Chạy ngầm ổn định, tắt màn hình vẫn truyền tiếp\n\n" +
                    "Phiên bản 1.1.0", 14f, SUB
            ),
            8
        )
        col.addV(about, 14)
        return sv
    }

    private fun infoRow(label: String, value: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.addView(tv(label, 14f, SUB), LinearLayout.LayoutParams(WRAP, WRAP))
        val v = tv(value, 14f, TEXT, true)
        v.gravity = Gravity.END
        r.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    /** Hiện đúng ảnh QR của tác giả (res/drawable-nodpi/donate_qr.png), phóng to không làm mờ. */
    private fun showDonateQr() {
        val opts = BitmapFactory.Options()
        opts.inScaled = false
        val bmp = BitmapFactory.decodeResource(resources, R.drawable.donate_qr, opts)
        val d = BitmapDrawable(resources, bmp)
        d.isFilterBitmap = false
        donateQr.setImageDrawable(d)
    }
}
