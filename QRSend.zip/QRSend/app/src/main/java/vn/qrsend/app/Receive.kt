package vn.qrsend.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/** Đích ghi một file đang nhận. */
class ReceiveTarget(
    val out: OutputStream,
    val displayName: String,
    private val onFinish: () -> Unit,
    private val onAbort: () -> Unit
) {
    fun finish() {
        try { out.flush() } catch (_: Exception) {}
        try { out.close() } catch (_: Exception) {}
        onFinish()
    }

    fun abort() {
        try { out.close() } catch (_: Exception) {}
        onAbort()
    }
}

/** Quản lý nơi lưu file nhận về (thư mục do người dùng chọn, hoặc mặc định). */
object ReceiveStore {
    private const val PREFS = "qrsend"
    private const val KEY_TREE = "save_tree"

    fun treeUri(ctx: Context): Uri? {
        val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TREE, null)
        return if (s.isNullOrEmpty()) null else Uri.parse(s)
    }

    fun setTree(ctx: Context, uri: Uri?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TREE, uri?.toString()).apply()
    }

    /** Mô tả nơi lưu để hiện trên giao diện. */
    fun describe(ctx: Context): String {
        val t = treeUri(ctx)
        if (t != null) {
            return try {
                val id = DocumentsContract.getTreeDocumentId(t)
                if (id.startsWith("primary:")) "Bộ nhớ trong/" + id.removePrefix("primary:") else id
            } catch (e: Exception) {
                t.toString()
            }
        }
        return if (Build.VERSION.SDK_INT >= 29) "Download/QRSend (mặc định)"
        else "Android/data/vn.qrsend.app/files/Download (mặc định)"
    }

    private fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun create(ctx: Context, name: String): ReceiveTarget {
        val mime = guessMime(name)
        val resolver = ctx.contentResolver

        // 1) Thư mục người dùng đã chọn (SAF)
        val tree = treeUri(ctx)
        if (tree != null) {
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val doc = DocumentsContract.createDocument(resolver, parent, mime, name)
                ?: throw java.io.IOException("Không tạo được file trong thư mục đã chọn")
            val os = resolver.openOutputStream(doc, "w")
                ?: throw java.io.IOException("Không mở được file để ghi")
            return ReceiveTarget(os, name, {}, {
                try { DocumentsContract.deleteDocument(resolver, doc) } catch (_: Exception) {}
            })
        }

        // 2) Mặc định: Download/QRSend (Android 10+)
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/QRSend")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw java.io.IOException("Không tạo được file trong Download")
            val os = resolver.openOutputStream(uri, "w")
                ?: throw java.io.IOException("Không mở được file để ghi")
            return ReceiveTarget(os, name, {
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                try { resolver.update(uri, done, null, null) } catch (_: Exception) {}
            }, {
                try { resolver.delete(uri, null, null) } catch (_: Exception) {}
            })
        }

        // 3) Android 8-9: thư mục riêng của app
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
        dir.mkdirs()
        var f = File(dir, name)
        var i = 1
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        while (f.exists()) {
            f = File(dir, base + " (" + i + ")" + (if (ext.isEmpty()) "" else "." + ext))
            i++
        }
        val file = f
        return ReceiveTarget(FileOutputStream(file), file.name, {}, { file.delete() })
    }
}
