package vn.qrsend.app

import android.net.Uri
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class SharedFile(
    val id: Int,
    val uri: Uri,
    val name: String,
    val size: Long,
    val mime: String
) {
    /** Vị trí byte mà lượt tải gần nhất đã gửi tới. */
    val progress = AtomicLong(0)
    /** Số lượt tải đang diễn ra. */
    val active = AtomicInteger(0)
    /** Số lượt tải đã hoàn tất. */
    val completed = AtomicInteger(0)
}

class ReceivedFile(val name: String, val total: Long) {
    val received = AtomicLong(0)
    /** 0 = đang nhận, 1 = xong, 2 = lỗi */
    @Volatile var state = 0
    @Volatile var savedAs: String = name
}

/** Trạng thái dùng chung giữa Activity và Service (cùng một process). */
object ShareState {
    val files = CopyOnWriteArrayList<SharedFile>()
    private val idGen = AtomicInteger(1)

    @Volatile var running = false
    @Volatile var url: String? = null
    @Volatile var token: String = ""
    @Volatile var error: String? = null

    @Volatile var receiveMode = false
    val received = CopyOnWriteArrayList<ReceivedFile>()
    val totalReceived = AtomicLong(0)

    val totalSent = AtomicLong(0)
    val activeConnections = AtomicInteger(0)

    fun nextId(): Int = idGen.getAndIncrement()
    fun find(id: Int): SharedFile? = files.firstOrNull { it.id == id }

    fun resetCounters() {
        totalSent.set(0)
        totalReceived.set(0)
        received.clear()
        activeConnections.set(0)
        for (f in files) {
            f.progress.set(0)
            f.active.set(0)
            f.completed.set(0)
        }
    }
}
