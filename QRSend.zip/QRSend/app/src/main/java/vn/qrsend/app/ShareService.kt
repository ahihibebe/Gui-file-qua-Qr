package vn.qrsend.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import java.security.SecureRandom

/**
 * Foreground Service giữ máy chủ HTTP sống khi tắt màn hình:
 * thông báo cố định + PARTIAL_WAKE_LOCK + WifiLock.
 */
class ShareService : Service() {

    companion object {
        const val ACTION_START = "vn.qrsend.app.START"
        const val ACTION_STOP = "vn.qrsend.app.STOP"
        private const val CHANNEL_ID = "share"
        private const val NOTIF_ID = 1001
    }

    private var server: HttpFileServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastBytes = 0L
    private var lastTime = 0L

    private val ticker = object : Runnable {
        override fun run() {
            updateNotification()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSharing()
            return START_NOT_STICKY
        }
        if (server == null) startSharing()
        return START_NOT_STICKY
    }

    private fun startSharing() {
        createChannel()
        val n = buildNotification("Đang khởi động…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }

        val ip = NetUtil.findLocalIp()
        if (ip == null) {
            ShareState.error = "Chưa kết nối Wi-Fi hoặc điểm phát sóng."
            stopSharing()
            return
        }
        if (ShareState.files.isEmpty() && !ShareState.receiveMode) {
            stopSharing()
            return
        }
        try {
            ShareState.token = randomToken()
            ShareState.resetCounters()
            val s = HttpFileServer(applicationContext)
            val port = s.start()
            server = s
            ShareState.url = "http://" + ip + ":" + port + "/" + ShareState.token + "/"
            ShareState.error = null
            acquireLocks()
            ShareState.running = true
            lastTime = 0L
            handler.post(ticker)
        } catch (e: Exception) {
            ShareState.error = "Không mở được máy chủ: " + e.message
            stopSharing()
        }
    }

    private fun stopSharing() {
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup() {
        handler.removeCallbacks(ticker)
        server?.stop()
        server = null
        releaseLocks()
        ShareState.running = false
        ShareState.url = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    // ---------- Khoá giữ máy thức ----------

    @SuppressLint("WakelockTimeout")
    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "qrsend:cpu").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }
        wifiLock = wm.createWifiLock(mode, "qrsend:wifi").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseLocks() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        try {
            wifiLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
        wifiLock = null
    }

    // ---------- Thông báo ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "Chia sẻ file", NotificationManager.IMPORTANCE_LOW)
        ch.description = "Hiển thị khi QR Send đang chia sẻ file"
        nm.createNotificationChannel(ch)
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(if (ShareState.receiveMode) "QR Send đang chờ nhận file" else "QR Send đang chia sẻ file")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Dừng chia sẻ", stop)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    private fun updateNotification() {
        val now = SystemClock.elapsedRealtime()
        val sent = ShareState.totalSent.get() + ShareState.totalReceived.get()
        val speed = if (lastTime > 0 && now > lastTime) (sent - lastBytes) * 1000 / (now - lastTime) else 0L
        lastTime = now
        lastBytes = sent
        val act = ShareState.activeConnections.get()
        val text = if (act > 0) {
            "Đang truyền " + act + " file • " + Fmt.size(speed) + "/s"
        } else if (ShareState.receiveMode) {
            "Sẵn sàng nhận • " + (ShareState.url ?: "")
        } else {
            "Sẵn sàng • " + ShareState.files.size + " file • " + (ShareState.url ?: "")
        }
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun randomToken(): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val r = SecureRandom()
        val sb = StringBuilder()
        for (i in 0 until 8) sb.append(chars[r.nextInt(chars.length)])
        return sb.toString()
    }
}
